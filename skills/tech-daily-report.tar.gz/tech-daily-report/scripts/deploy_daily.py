#!/usr/bin/env python3
"""Deploy a daily report draft to taoleb/daily-news-pages.

Usage:
  python3 scripts/deploy_daily.py <tech|auto> <draft.html> <中文日期>

Writes:
  <section>/index.html
  archive/<section>-YYYY-MM-DD.html
"""
import base64, json, os, re, sys, urllib.error, urllib.request

REPO = "taoleb/daily-news-pages"
API = "https://api.github.com"


def die(msg):
    print(json.dumps({"ok": False, "error": msg}, ensure_ascii=False))
    sys.exit(1)


def request(method, path, payload=None):
    token = os.environ.get("GITHUB_TOKEN")
    if not token:
        die("GITHUB_TOKEN missing")
    data = None if payload is None else json.dumps(payload).encode()
    req = urllib.request.Request(
        API + path,
        data=data,
        method=method,
        headers={
            "Authorization": f"Bearer {token}",
            "Accept": "application/vnd.github+json",
            "User-Agent": "cow-daily-deploy",
            "Content-Type": "application/json",
        },
    )
    try:
        with urllib.request.urlopen(req, timeout=40) as resp:
            body = resp.read().decode()
            return resp.status, json.loads(body) if body else {}
    except urllib.error.HTTPError as exc:
        err = exc.read().decode()[:500]
        return exc.code, {"message": err}


def put_file(path, content, message):
    _, meta = request("GET", f"/repos/{REPO}/contents/{path}")
    sha = meta.get("sha") if isinstance(meta, dict) else None
    payload = {
        "message": message,
        "content": base64.b64encode(content.encode()).decode(),
        "branch": "main",
    }
    if sha:
        payload["sha"] = sha
    status, body = request("PUT", f"/repos/{REPO}/contents/{path}", payload)
    if status == 422:
        _, meta = request("GET", f"/repos/{REPO}/contents/{path}")
        payload["sha"] = meta.get("sha")
        status, body = request("PUT", f"/repos/{REPO}/contents/{path}", payload)
    if status not in (200, 201):
        die(f"upload {path} failed: {status} {body}")
    commit = (body.get("commit") or {}).get("sha")
    return commit


def main():
    if len(sys.argv) != 4:
        die("usage: deploy_daily.py <tech|auto> <draft.html> <中文日期>")
    section, draft, cn_date = sys.argv[1:]
    if section not in ("tech", "auto"):
        die("section must be tech or auto")
    iso = re.search(r"(\d{4})年(\d{1,2})月(\d{1,2})日", cn_date)
    if not iso:
        die("date must look like 2026年10月13日")
    y, m, d = iso.groups()
    day = f"{int(y):04d}-{int(m):02d}-{int(d):02d}"
    with open(draft, encoding="utf-8") as fh:
        html = fh.read()
    if "<article" not in html:
        die("draft has no articles")
    msg = f"daily: update {section} {day}"
    c1 = put_file(f"{section}/index.html", html, msg)
    c2 = put_file(f"archive/{section}-{day}.html", html, f"daily: archive {section} {day}")
    print(json.dumps({
        "ok": True,
        "section": section,
        "date": day,
        "url": f"https://taoleb.github.io/daily-news-pages/{section}/",
        "archive": f"https://taoleb.github.io/daily-news-pages/archive/{section}-{day}.html",
        "commits": [c1, c2],
    }, ensure_ascii=False))


if __name__ == "__main__":
    main()
