#!/usr/bin/env python3
"""
科技早报资讯采集脚本
流程: RSS订阅源 + 门户网站抓取 -> Tavily关键词补充 -> 去重 -> 去过时 -> 输出候选JSON
用法: python3 collect_news.py [--date 2026-10-13]
输出: /home/agent/cow/tmp/tech_candidates.json
依赖: 仅Python标准库(环境无curl, 用urllib)
"""
import os, sys, json, re, html as htmllib, urllib.request, urllib.error, urllib.parse
import xml.etree.ElementTree as ET
from email.utils import parsedate_to_datetime
from datetime import datetime, timezone, timedelta

CST = timezone(timedelta(hours=8))
TMP = '/home/agent/cow/tmp'
TAVILY_KEYS = ['TAVILY_API_KEY', 'TAVILY_API_KEY_2', 'TAVILY_API_KEY_3',
               'TAVILY_API_KEY_4', 'TAVILY_API_KEY_5']

# ---------- 信息源配置 ----------
RSS_FEEDS = [
    # 国际科技/AI
    {'name': 'TechCrunch', 'url': 'https://techcrunch.com/feed/', 'region': 'global'},
    {'name': 'The Verge', 'url': 'https://www.theverge.com/rss/index.xml', 'region': 'global'},
    {'name': 'Ars Technica', 'url': 'https://feeds.arstechnica.com/arstechnica/index', 'region': 'global'},
    {'name': 'Hacker News', 'url': 'https://hnrss.org/frontpage', 'region': 'global'},
    {'name': 'VentureBeat AI', 'url': 'https://venturebeat.com/category/ai/feed/', 'region': 'global'},
    {'name': 'Reuters Tech', 'url': 'https://news.google.com/rss/search?q=when:1d+allinurl:reuters.com+technology&hl=en-US&gl=US&ceid=US:en', 'region': 'global'},
    # 国内科技/AI
    {'name': '量子位', 'url': 'https://www.qbitai.com/feed', 'region': 'cn'},
    {'name': '36氪', 'url': 'https://36kr.com/feed', 'region': 'cn'},
    {'name': '少数派', 'url': 'https://sspai.com/feed', 'region': 'cn'},
    {'name': '机器之心(Google News)', 'url': 'https://news.google.com/rss/search?q=when:1d+机器之心+OR+Synced+AI&hl=zh-CN&gl=CN&ceid=CN:zh-Hans', 'region': 'cn'},
    {'name': 'Google News 中文科技', 'url': 'https://news.google.com/rss/search?q=when:1d+人工智能+OR+大模型+OR+芯片&hl=zh-CN&gl=CN&ceid=CN:zh-Hans', 'region': 'cn'},
]

PORTALS = [
    {'name': 'LLM Gateway Timeline', 'url': 'https://llmgateway.io/timeline', 'type': 'model_releases'},
    {'name': '量子位首页', 'url': 'https://www.qbitai.com', 'type': ' headlines'},
]

# Tavily 补充查询（覆盖 RSS 盲区: 官方公告、国内深度报道）
TAVILY_QUERIES = [
    'AI model release announcement announcement today',
    '人工智能 大模型 发布 国内 最新',
    'AI chip semiconductor compute announcement',
    'AI startup funding billion this week',
    'open source AI agent framework release',
]

UA = {'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36'}
STOP_TITLE = re.compile(r'(hacked by|敏感|赌|色情)', re.I)


def http_get(url, timeout=25):
    # URL 含非 ASCII（中文）时需编码
    safe_url = urllib.parse.quote(url, safe=':/?&=%#[]@!$\'()*+,;~-._')
    req = urllib.request.Request(safe_url, headers=UA)
    return urllib.request.urlopen(req, timeout=timeout).read()


def parse_ts(s):
    if not s:
        return None
    try:
        return parsedate_to_datetime(s).astimezone(CST)
    except Exception:
        pass
    for fmt in ('%Y-%m-%dT%H:%M:%S%z', '%Y-%m-%dT%H:%M:%SZ', '%Y-%m-%d %H:%M:%S'):
        try:
            return datetime.strptime(s.replace('Z', '+0000') if fmt.endswith('%z') else s, fmt).astimezone(CST)
        except Exception:
            continue
    return None


def clean_text(s):
    s = htmllib.unescape(re.sub(r'<[^>]+>', '', s or ''))
    return re.sub(r'\s+', ' ', s).strip()


def fetch_rss(feed):
    items = []
    try:
        raw = http_get(feed['url'], timeout=20)
        root = ET.fromstring(raw)
        nodes = root.iter('item') if root.iter('item') else root.iter('entry')
        for node in list(nodes)[:30]:
            def g(tag, ns=None):
                el = node.find(tag)
                if el is not None:
                    return el
                for c in node:
                    if c.tag.split('}')[-1] == tag:
                        return c
                return None
            title = clean_text((g('title').text or '') if g('title') is not None else '')
            link = ''
            le = g('link')
            if le is not None:
                link = (le.text or '').strip() or le.get('href', '')
            pub = None
            for t in ('pubDate', 'published', 'updated'):
                pub = g(t)
                if pub is not None:
                    break
            ts = parse_ts(pub.text if pub is not None else None)
            desc = clean_text((g('description').text or '') if g('description') is not None else '')[:300]
            if title and link:
                items.append({'title': title, 'url': link.split('?utm')[0].split('&utm')[0],
                              'source': feed['name'], 'region': feed['region'],
                              'time': ts.isoformat() if ts else None, 'summary': desc})
    except Exception as e:
        print(f'  [RSS失败] {feed["name"]}: {e}', file=sys.stderr)
    return items


def fetch_portal(p):
    """门户网站: 抓取页面抽取最新条目(标题+链接), 主要用于模型发布时间线"""
    items = []
    try:
        html_text = http_get(p['url']).decode('utf-8', 'ignore')
        text = re.sub(r'<script.*?</script>|<style.*?</style>', '', html_text, flags=re.S)
        if p['type'] == 'model_releases':
            # llmgateway timeline: 抓 "ModelName Provider · Month D, YYYY" 模式
            plain = clean_text(text)
            for m in re.finditer(r'([A-Za-z0-9\-\. ]{3,40}?) ((?:Meta|[OI]|Google|Microsoft|Reka|Alibaba|Qwen|DeepSeek|Anthropic|Mistral|xAI|Tencent|ByteDance|NVIDIA)) · (January|February|March|April|May|June|July|August|September|October|November|December) (\d{1,2}), (\d{4})', plain):
                name, prov, mon, day, yr = m.groups()
                items.append({'title': f'{prov} 发布 {name.strip()}',
                              'url': p['url'], 'source': p['name'], 'region': 'global',
                              'time': f'{yr}-{mon}-{day}', 'summary': ''})
    except Exception as e:
        print(f'  [门户失败] {p["name"]}: {e}', file=sys.stderr)
    return items


def tavily_search(query):
    for key_name in TAVILY_KEYS:
        key = os.environ.get(key_name)
        if not key:
            continue
        try:
            req = urllib.request.Request('https://api.tavily.com/search',
                data=json.dumps({'api_key': key, 'query': query, 'max_results': 8,
                                 'search_depth': 'basic', 'topic': 'news',
                                 'days': 1}).encode(),
                headers={'Content-Type': 'application/json'})
            d = json.load(urllib.request.urlopen(req, timeout=60))
            return [{'title': clean_text(r['title']), 'url': r['url'], 'source': 'Tavily',
                     'region': 'global', 'time': r.get('published_date'),
                     'summary': clean_text(r.get('content', ''))[:300]} for r in d.get('results', [])]
        except urllib.error.HTTPError as e:
            print(f'  [Tavily] {key_name} HTTP {e.code}, 换下一个 key', file=sys.stderr)
        except Exception as e:
            print(f'  [Tavily] {key_name}: {e}', file=sys.stderr)
    return []


def norm_title(t):
    t = re.sub(r'[^\w\u4e00-\u9fff]', '', t.lower())
    noise = ['科技早报', '快讯', '最新', '刚刚', '独家', 'theverge', 'reuters', '报道']
    for n in noise:
        t = t.replace(n, '')
    return t


def dedup_and_filter(items, hours=36):
    """去重(标题规范化+URL) + 去过时(默认保留36h内) + 过滤垃圾与聚合页"""
    seen_urls, seen_titles = set(), []
    now = datetime.now(CST)
    # Tavily 结果多为列表页/聚合页/视频页, 剔除低信息量域名
    AGG_HOSTS = ('youtube.com', 'youtu.be', 'facebook.com', 'x.com', 'twitter.com')
    LIST_HOSTS = ('llm-stats.com/ai-news', 'llmgateway.io', 'aimlapi.com', 'llm-stats.com/models',
                  'pricepertoken.com', 'aireleasetracker.com')
    out, dropped_old, dropped_dup = [], 0, 0
    for it in items:
        t = it['title']
        if not t or len(t) < 10 or STOP_TITLE.search(t):
            continue
        u = it['url'].rstrip('/')
        host_path = u.split('//', 1)[-1]
        is_tavily = it.get('source') == 'Tavily'
        if is_tavily and (any(h in host_path for h in AGG_HOSTS) or any(h in host_path for h in LIST_HOSTS)):
            dropped_dup += 1
            continue
        if u in seen_urls:
            dropped_dup += 1
            continue
        nt = norm_title(t)
        if any(nt == s or (len(nt) > 12 and nt in s) or (len(s) > 12 and s in nt) for s in seen_titles):
            dropped_dup += 1
            continue
        # 时间过滤
        ts = None
        if it.get('time'):
            ts = parse_ts(it['time']) or (datetime.fromisoformat(it['time']) if 'T' in it['time'] else None)
        if ts:
            age_h = (now - ts).total_seconds() / 3600
            if age_h > hours or age_h < -2:  # 超36h 或 未来时间
                dropped_old += 1
                continue
            it['_age_h'] = round(age_h, 1)
        elif is_tavily:
            # Tavily 无发布时间: 搜索时已用时间限定词约束, 保留但标记供AI策展时二次甄别
            it['_age_unverified'] = True
        seen_urls.add(u)
        seen_titles.append(nt)
        it.pop('summary', None) if not it.get('summary') else None
        out.append(it)
    print(f'原始 {len(items)} 条 -> 有效 {len(out)} 条 (去重 {dropped_dup}, 过旧/无效 {dropped_old})', file=sys.stderr)
    return out


def main():
    all_items = []
    print('== 1. RSS 订阅源 ==', file=sys.stderr)
    for f in RSS_FEEDS:
        got = fetch_rss(f)
        print(f'  {f["name"]}: {len(got)} 条', file=sys.stderr)
        all_items += got

    print('== 2. 门户网站 ==', file=sys.stderr)
    for p in PORTALS:
        got = fetch_portal(p)
        print(f'  {p["name"]}: {len(got)} 条', file=sys.stderr)
        all_items += got

    print('== 3. Tavily 关键词补充 ==', file=sys.stderr)
    for q in TAVILY_QUERIES:
        got = tavily_search(q)
        print(f'  "{q[:40]}": {len(got)} 条', file=sys.stderr)
        all_items += got

    print('== 4. 去重 + 去过时 ==', file=sys.stderr)
    final = dedup_and_filter(all_items)

    os.makedirs(TMP, exist_ok=True)
    out_path = os.path.join(TMP, 'tech_candidates.json')
    json.dump(final, open(out_path, 'w'), ensure_ascii=False, indent=1)
    print(f'输出: {out_path} ({len(final)} 条候选)', file=sys.stderr)


if __name__ == '__main__':
    main()
