---
name: tech-daily-report
description: >
  每日科技早报生成与部署技能。用 RSS 订阅源 + 门户网站 + Tavily 关键词搜索三路采集
  24h 内国内外科技/AI 资讯，去重去过时后精选 15 条，生成早报网页并部署到 GitHub Pages。
  Use when: (1) 定时任务在每天早上生成科技早报, (2) 用户要求"生成科技早报/科技日报",
  (3) 用户要求更新 daily-news-pages 的 tech 版块, (4) 用户询问今日科技新闻摘要。
metadata:
  requires:
    bins: ["python3"]
    env: ["GITHUB_TOKEN", "TAVILY_API_KEY"]
  emoji: 📡
---

# 科技早报生成技能

每日早报流水线：**采集 → 策展 → 生成 HTML → 部署 → 汇报**。产出固定 15 条、国内外兼顾、24 小时内资讯。

## 流程总览

```
1. 采集   python3 <base_dir>/scripts/collect_news.py     (RSS×10 + 门户×2 + Tavily×5)
2. 策展   读 tmp/tech_candidates.json → AI 精选 15 条
3. 生成   按 assets/template.html 风格写 tmp/tech_daily_draft.html
4. 部署   python3 "<base_dir>/scripts/deploy_daily.py" tech <draft> "中文日期"
5. 汇报   条目数 + 3~5 条头条 + 线上链接
```

## Step 1 — 采集

```bash
python3 "<base_dir>/scripts/collect_news.py"
```

- 输出：`/home/agent/cow/tmp/tech_candidates.json`，字段：title / url / source / region(cn|global) / time / _age_h / _age_unverified / summary
- 脚本已内置：去重（URL+标题规范化）、去过时（36h 窗口）、聚合页过滤（YouTube/FB/列表站）、Tavily key 轮换（_2~_5，429 或超额自动切换）
- **策展候选以 RSS（有时间戳）为主，`_age_unverified: true` 的 Tavily 条目需人工（AI）甄别时效后才可入选**
- 单源失败不阻塞（如 36氪 RSS 格式异常、VentureBeat 429），Tavily 兜底；若 RSS 总产出 < 20 条，在 SKILL 执行时追加 2~3 组临时 Tavily 查询（用 bash + python 调 `scripts/collect_news.py` 里的 `tavily_search()`）

## Step 2 — AI 策展（精选 15 条）

读取 `tmp/tech_candidates.json`，按以下规则挑选：

1. **数量**：固定 **15 条**独立事件（不足时可用 Tavily 补搜，宁缺毋滥不凑数——但 14 条以下需在汇报中说明）
2. **配比**：国内 5~8 条 / 国际 7~10 条；单一公司/事件最多 2 条
3. **时效**：优先 `_age_h` 最小者；`_age_unverified` 条目打开链接确认确为 24h 内才收录
4. **板块分组**（每期 3~5 个板块）：
   - 模型与 Agent（模型发布、开源框架、编程工具）
   - 芯片与算力（半导体、数据中心、基础设施）
   - 前沿研究（论文、能力评测、AI4Science）
   - 行业与投融资（融资、政策、大厂动态）
   - 其他（安全治理、开源社区等，视内容而定）
5. **每条结构**：中文标题（重写，不照搬原题）→ 来源标签（官方/媒体/社区 + 国内/国际）→ 核心事实（1~2 句，含关键数字）→ 详情（可选）→ 原文链接
6. **红线**：无法核实的不收录；标题不夸大；同事件多来源合并为一条（选信息量最大的来源做主链接）

## Step 3 — 生成 HTML

以 `assets/template.html` 为骨架（含完整 CSS，与 daily-news-pages 站点视觉一致），替换：

- `<title>` 与 hero 标题：`📡 科技早报 · YYYY年M月D日（星期X）`
- hero 副标题：`覆盖最近24小时（M月D日—M月D日晨）`
- meta 行：`今日共收录 15 条独立事件：国内来源 X 条 / 国际来源 Y 条` + 当期板块 badge
- 每条事件 = 一个 `<article class="item">`，按板块 `<section>` 分组
- 生成到 `/home/agent/cow/tmp/tech_daily_draft.html`

## Step 4 — 部署

```bash
python3 "<base_dir>/scripts/deploy_daily.py" tech /home/agent/cow/tmp/tech_daily_draft.html "YYYY年M月D日"
```

- 自动写两个文件：`tech/index.html`（版块首页，覆盖）+ `archive/tech-YYYY-MM-DD.html`（按日归档）
- 输出 JSON 含 url / archive / commits，部署后用 `web_fetch` 或 urllib 验证线上可达（Pages 构建约需 30~60s，首次 404 可等 30s 重试）

## Step 5 — 汇报格式

```
📡 科技早报已发布（M月D日）
· 收录 15 条（国内 X / 国际 Y）
· 头条：3~5 条一句话摘要
· 链接：https://taoleb.github.io/daily-news-pages/tech/
· 归档：https://taoleb.github.io/daily-news-pages/archive/tech-YYYY-MM-DD.html
```

## 关联资源

- 部署脚本：`<base_dir>/scripts/deploy_daily.py`（随本技能打包；`base_dir` 是本 SKILL.md 所在目录。若工作区根目录也有一份 `scripts/deploy_daily.py`，两处应保持同一份副本）
- 站点导航首页：https://taoleb.github.io/daily-news-pages/
- 流程规范（背景）：`/home/agent/cow/knowledge/daily-report-sop.md`
- 汽车早报（姊妹技能，同构）：改用汽车查询组与 auto/ 目录，流程一致

## 故障处理

| 症状 | 处置 |
|---|---|
| RSS 大面积失败 | 检查网络；追加 Tavily 查询兜底（topic=news, days=1） |
| Tavily 全部 429/额度尽 | 依次检查 TAVILY_API_KEY_2~_5；都耗尽则仅用 RSS 出报并说明 |
| 部署 422 | 文件 sha 冲突，脚本已内置 sha 获取重试；仍失败检查 GITHUB_TOKEN 权限（需 Contents 读写） |
| 线上 404 | Pages 构建延迟，等 30~60s 重试验证 |
| 候选不足 15 条 | 用 Tavily 补查（查询词见脚本内 TAVILY_QUERIES 扩展），仍不足则如实出报 |
