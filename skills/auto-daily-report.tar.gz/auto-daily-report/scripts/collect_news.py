#!/usr/bin/env python3
"""
汽车产业早报资讯采集脚本 (与 tech-daily-report 同构)
产业雷达八赛道: 产品 / 智驾 / 监管 / 电动化 / 汽车电子 / 能源基础设施 / 供应链 / 全球产业
流程: RSS订阅源 + 门户网站抓取 -> Tavily关键词补充 -> 去重 -> 去过时 -> 输出候选JSON
用法: python3 collect_news.py [--date 2026-10-13]
输出: /home/agent/cow/tmp/auto_candidates.json
依赖: 仅Python标准库(环境无curl, 用urllib)
"""
import os, sys, json, re, html as htmllib, urllib.request, urllib.error, urllib.parse
import xml.etree.ElementTree as ET
from email.utils import parsedate_to_datetime
from datetime import datetime, timezone, timedelta

CST = timezone(timedelta(hours=8))
TMP = '/home/agent/cow/tmp'
TAVILY_KEYS = ['TAVILY_API_KEY', 'TAVILY_API_KEY_2', 'TAVILY_API_KEY_3',
               'TAVILY_API_KEY_4', 'TAVILY_API_KEY_5']

# ---------- 产业雷达: 八赛道 -> Tavily 查询组 ----------
# 赛道标签: product产品 / adas智驾 / regulation监管 / ev电动化
#           electronics汽车电子 / energy能源基础设施 / supply供应链 / global全球产业
TAVILY_QUERIES = [
    {'q': 'new car model launch announcement today',        'track': 'product'},
    {'q': 'automotive autonomous driving announcement',      'track': 'adas'},
    {'q': '智能驾驶 自动驾驶 发布 进展',                       'track': 'adas'},
    {'q': 'NHTSA regulation autonomous vehicle policy',      'track': 'regulation'},
    {'q': '汽车 政策 监管 工信部 通知',                        'track': 'regulation'},
    {'q': 'electric vehicle battery EV announcement',        'track': 'ev'},
    {'q': '动力电池 充电 新能源汽车',                          'track': 'ev'},
    {'q': 'automotive chip semiconductor electronics car',   'track': 'electronics'},
    {'q': 'charging network EV charging infrastructure',     'track': 'energy'},
    {'q': 'automotive supply chain battery materials',       'track': 'supply'},
    {'q': 'global auto industry OEM plant investment',       'track': 'global'},
]

# ---------- 信息源配置 ----------
RSS_FEEDS = [
    # 国际汽车 (注: news.google.com 本环境不通, 已弃用GN中转源)
    {'name': 'Electrek', 'url': 'https://electrek.co/feed/', 'region': 'global'},
    {'name': 'CnEVPost', 'url': 'https://cnevpost.com/feed/', 'region': 'global'},  # 中国EV出海英文快讯, 兼作国内信源
    {'name': 'Ars Technica Cars', 'url': 'https://feeds.arstechnica.com/arstechnica/cars', 'region': 'global'},
    {'name': 'Carscoops', 'url': 'https://www.carscoops.com/feed/', 'region': 'global'},
    {'name': 'TechCrunch Transportation', 'url': 'https://techcrunch.com/category/transportation/feed/', 'region': 'global'},
    {'name': 'The Verge(策展时过滤非汽车)', 'url': 'https://www.theverge.com/rss/index.xml', 'region': 'global'},
]

# 门户直接抓取(启发式<a>文本长度过滤)
PORTALS = [
    {'name': '第一电动网-新闻', 'url': 'https://www.d1ev.com/news', 'type': 'auto_headlines'},  # 首页JS渲染无静态链接, 用栏目页
]

UA = {'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36'}
STOP_TITLE = re.compile(r'(hacked by|敏感|赌|色情)')


def http_get(url, timeout=25):
    # URL 含非 ASCII（中文）时需编码
    safe_url = urllib.parse.quote(url, safe=':/?&=%#[]@!$\'()*+,;~-._')
    req = urllib.request.Request(safe_url, headers=UA)
    return urllib.request.urlopen(req, timeout=timeout).read()


def clean_text(t):
    if not t:
        return ''
    t = htmllib.unescape(re.sub(r'<[^>]+>', '', str(t)))
    return re.sub(r'\s+', ' ', t).strip()


def parse_time(s):
    if not s:
        return None
    try:
        return parsedate_to_datetime(s).astimezone(CST)
    except Exception:
        pass
    try:
        d = datetime.fromisoformat(s.replace('Z', '+00:00'))
        if d.tzinfo is None:
            d = d.replace(tzinfo=CST)
        return d.astimezone(CST)
    except Exception:
        pass
    for fmt in ('%Y-%m-%d %H:%M:%S', '%Y-%m-%d'):
        try:
            return datetime.strptime(s.strip()[:19], fmt).replace(tzinfo=CST)
        except Exception:
            continue
    return None


def norm_title(t):
    return re.sub(r'[\s\W_]+', '', (t or '').lower())[:40]


AGG_BLACKLIST = re.compile(
    r'(youtube\.com|facebook\.com|instagram\.com|x\.com|twitter\.com|tiktok\.com'
    r'|reddit\.com/r|news\.ycombinator\.com/item|bilibili\.com|douyin\.com'
    r'|/video/|/videos/|gallery|/photos/|/slideshow|newsletter|podcast'
    r'|\.pdf$|/topic/|/tag/|/category/|\.mp3|\.mp4)', re.I)


def is_aggregator(url):
    return bool(AGG_BLACKLIST.search(url or ''))


# ---------- 1. RSS ----------
def fetch_rss(feed, hours=36):
    items = []
    try:
        raw = http_get(feed['url'], timeout=20)
        root = ET.fromstring(raw)
        # RSS2: item / Atom: entry
        nodes = root.iter()
        for el in nodes:
            if el.tag.endswith(('item', 'entry')):
                def gt(tag):
                    for c in el:
                        if c.tag.split('}')[-1] == tag:
                            return c
                def gt_any(*tags):
                    for tg in tags:
                        c = gt(tg)
                        if c is not None and c.text:
                            return c
                    return None
                title, link = gt('title'), gt('link')
                pub = gt_any('pubDate', 'updated', 'published')
                if title is None:
                    continue
                # Atom link 是属性
                link_url = ''
                if link is not None:
                    link_url = (link.get('href') or (link.text or '')).strip()
                t = clean_text(title.text)
                if not t or STOP_TITLE.search(t):
                    continue
                items.append({'title': t, 'url': link_url, 'source': feed['name'],
                              'region': feed.get('region', 'global'),
                              'time': pub.text if pub is not None else None,
                              'summary': clean_text(gt('description').text)[:300] if gt('description') is not None and gt('description').text else ''})
    except Exception as e:
        print(f'  [RSS] {feed["name"]}: {e}', file=sys.stderr)
    return items


# ---------- 2. 门户 ----------
def fetch_portal(portal, hours=36):
    items = []
    try:
        html_text = http_get(portal['url'], timeout=20).decode('utf-8', 'ignore')
        seen = set()
        for m in re.finditer(r'<a[^>]+href="([^"]+)"[^>]*>([^<]{8,60})</a>', html_text):
            url, title = m.group(1), clean_text(m.group(2))
            if url.startswith('javascript') or url in seen or STOP_TITLE.search(title):
                continue
            if not re.search(r'(news|article|/\d{5,}|html)', url):
                continue
            seen.add(url)
            items.append({'title': title, 'url': urllib.parse.urljoin(portal['url'], url),
                          'source': portal['name'], 'region': 'cn', 'time': None, 'summary': ''})
        items = items[:20]
    except Exception as e:
        print(f'  [门户] {portal["name"]}: {e}', file=sys.stderr)
    return items


# ---------- 3. Tavily ----------
def tavily_search(query, track):
    for key_name in TAVILY_KEYS:
        key = os.environ.get(key_name)
        if not key:
            continue
        try:
            req = urllib.request.Request('https://api.tavily.com/search',
                data=json.dumps({'api_key': key, 'query': query, 'max_results': 8,
                                 'search_depth': 'basic', 'topic': 'news',
                                 'days': 1}).encode(),
                headers={'Content-Type': 'application/json'})
            d = json.load(urllib.request.urlopen(req, timeout=60))
            return [{'title': clean_text(r['title']), 'url': r['url'], 'source': 'Tavily',
                     'region': 'global', 'track': track,
                     'time': r.get('published_date'),
                     'summary': clean_text(r.get('content', ''))[:300]} for r in d.get('results', [])]
        except urllib.error.HTTPError as e:
            print(f'  [Tavily] {key_name} HTTP {e.code}, 换下一个 key', file=sys.stderr)
        except Exception as e:
            print(f'  [Tavily] {key_name}: {e}', file=sys.stderr)
    return []


# ---------- 4. 去重 + 去过时 ----------
def dedup_filter(all_items, hours=36):
    now = datetime.now(CST)
    seen_urls, seen_titles = set(), []
    valid, dropped_dup, dropped_old = [], 0, 0
    for it in all_items:
        u = (it.get('url') or '').split('?')[0].split('#')[0]
        nt = norm_title(it['title'])
        if not u or is_aggregator(u) or STOP_TITLE.search(it['title']):
            dropped_old += 1
            continue
        if u in seen_urls or any(nt == s or (len(nt) > 12 and nt in s) or (len(s) > 12 and s in nt) for s in seen_titles):
            dropped_dup += 1
            continue
        ts = parse_time(it.get('time'))
        if ts:
            age_h = (now - ts).total_seconds() / 3600
            if age_h > hours or age_h < -2:  # 超36h 或 未来时间
                dropped_old += 1
                continue
            it['_age_h'] = round(age_h, 1)
        elif it.get('source') == 'Tavily':
            # Tavily 无发布时间: 搜索时已用 topic=news+days=1 约束, 保留标记供AI策展时二次甄别
            it['_age_unverified'] = True
        seen_urls.add(u)
        seen_titles.append(nt)
        it['time_cst'] = ts.strftime('%Y-%m-%d %H:%M') if ts else None
        valid.append(it)
    print(f'原始 {len(all_items)} 条 -> 有效 {len(valid)} 条 (去重 {dropped_dup}, 过旧/无效 {dropped_old})')
    return valid


def main():
    now = datetime.now(CST)
    print(f'== 汽车产业早报采集 @ {now.strftime("%Y-%m-%d %H:%M")} CST')
    all_items = []
    # 1. RSS
    print('== 1. RSS 订阅源')
    for feed in RSS_FEEDS:
        got = fetch_rss(feed)
        print(f'  {feed["name"]}: {len(got)} 条')
        all_items += got
    # 2. 门户
    print('== 2. 门户网站')
    for portal in PORTALS:
        got = fetch_portal(portal)
        print(f'  {portal["name"]}: {len(got)} 条')
        all_items += got
    # 3. Tavily 八赛道关键词补充
    print('== 3. Tavily 赛道补充 (八赛道)')
    for spec in TAVILY_QUERIES:
        got = tavily_search(spec['q'], spec['track'])
        print(f'  [{spec["track"]}] "{spec["q"][:36]}": {len(got)} 条')
        all_items += got
    # 4. 清洗
    print('== 4. 去重 + 去过时')
    valid = dedup_filter(all_items)
    out = os.path.join(TMP, 'auto_candidates.json')
    os.makedirs(TMP, exist_ok=True)
    json.dump(valid, open(out, 'w'), ensure_ascii=False, indent=1)
    print(f'输出: {out} ({len(valid)} 条候选)')
    # 目标池: 20-40条; 不足时提示
    if len(valid) < 20:
        print(f'⚠️ 候选池 {len(valid)} < 20, 策展阶段需 Tavily 追加查询', file=sys.stderr)
    return valid


if __name__ == '__main__':
    main()
