---
name: auto-daily-report
description: >
  每日汽车产业早报生成与部署技能。按产品、智驾、监管、电动化、汽车电子、能源基础设施、供应链、全球产业八赛道，利用 RSS、门户、Tavily 多源采集，时间与事实验证、事件聚类、产业影响评分，精选 8—20 条并发布 GitHub Pages。
  Use when: 用户要求生成/更新汽车早报、汽车产业日报，或每日定时任务执行汽车产业动态雷达。
metadata:
  requires:
    bins: ["python3"]
    env: ["GITHUB_TOKEN", "TAVILY_API_KEY"]
  emoji: 🚗
---

# 汽车产业动态雷达 — 每日早报技能

核心链路：**八赛道扫描 → 多源候选池（目标20—40个独立事件）→ 时间验证 + 事实验证 → 事件聚类 → 产业影响评分 → 最终日报（8—20条）→ 部署**。

## 八赛道

1. **产品**：新车发布、改款、定价、销量、车型策略
2. **智驾**：L2+/L3/L4、Robotaxi、自动驾驶事故与技术
3. **监管**：法规、召回、安全调查、准入与贸易政策
4. **电动化**：纯电/混动、动力电池、快充、储能
5. **汽车电子**：芯片、车载OS、座舱、传感器、域控
6. **能源基础设施**：充电网络、换电、V2G、电网与能源协同
7. **供应链**：电池材料、零部件、产能、采购与供应协议
8. **全球产业**：车企财报、并购、建厂、出口、区域市场变化

## Step 1 — 采集候选

```bash
python3 /home/agent/cow/skills/auto-daily-report/scripts/collect_news.py
```

- 输出 `/home/agent/cow/tmp/auto_candidates.json`
- 多源：RSS（Electrek、CnEVPost、Ars Technica Cars、Carscoops、TechCrunch Transportation 等）+ 第一电动门户 + Tavily 八赛道查询
- 去重（URL + 标题）、聚合页过滤、36小时窗口；Tavily 使用 `topic=news, days=1`
- 目标候选池 20—40 个**独立事件**。脚本原始抓取可多于40条，策展时需聚类归并
- RSS 条目以 `_age_h` 提供可验证时效；Tavily 若无时间戳会标 `_age_unverified`，必须点开原文确认发布时间
- 当前环境 Google News RSS 不可达；勿依赖 Google News 中转源。失效源不阻塞，Tavily 兜底

## Step 2 — 时间验证、事实验证、事件聚类

读取候选 JSON，按流程执行：

### 时间验证
- 默认 24 小时窗口（日报覆盖前一日晨至当日晨）；采集层先用 36 小时容错
- `_age_h > 24` 原则上不入选；若确属重大事件且仍在持续，可例外但清楚标注事件发生时间
- `_age_unverified` 必须打开原文确认时间，无法确认则不收录

### 事实验证
- 对拟选条目回溯一手来源：车企/监管机构/交易所公告优先，其次可靠媒体；搜索摘要不是一手证据
- 涉及数字、法规、事故、未确认交易或传闻，至少核对原文；重大或争议事件尽可能双源交叉验证
- 明确区分：已确认 / 公司声称 / 媒体报道 / 市场传闻；不把传闻写成事实
- 无法打开原文或数字互相冲突时，降低确定性表述或剔除

### 事件聚类
- 同一发布/交易/事故/政策的多篇报道合并为一个事件，保留最权威且信息最完整的主链接
- 同一事件的后续进展若带来实质新信息（如监管立案、最终定价）可作为独立更新
- 目标候选从多源原始结果归并为 20—40 个独立事件，再进入评分

## Step 3 — 产业影响评分与选稿

每条候选按 1—5 分评分并简记理由：

- **产业影响**（权重×3）：是否改变成本、技术路线、竞争格局或商业化节奏
- **市场影响**（权重×2）：涉及规模、销量、资金、产能、重要市场
- **时效性**（权重×2）：新近发生、当前正在发展
- **可信度**（权重×2）：一手来源、官方文件、可靠媒体/多源确认
- **中国相关性**（权重×1）：对中国车企、供应链、政策或市场的影响

总分 = 产业影响×3 + 市场影响×2 + 时效性×2 + 可信度×2 + 中国相关性×1（满分50）。优先选总分高且赛道互补的事件。

- 每期 **8—20 条**，默认 12—15 条；重大新闻多时可到20，信息不足可低于12但不得凑数
- 尽量覆盖 4 个以上赛道；产品/智驾/监管/电动化为常见主干，电子/能源/供应链/全球产业按当日实事补充
- 国内/国际平衡但不机械对半；单一公司原则上不超过3条
- 每条须有：中文标题、赛道标签、地区标签、事实摘要（1—2句）、影响判断（1句）、来源与原文链接

## Step 4 — 生成 HTML

- 以 `/home/agent/cow/skills/auto-daily-report/assets/template.html` 为视觉骨架；主题色汽车绿
- 页面标题：`🚗 汽车产业早报 · YYYY年M月D日（星期X）`
- hero 标明时间窗口、条目数、国内/国际分布与覆盖赛道
- 按 3—6 个产业赛道分组，每条一个 `<article class="item">`
- 写入 `/home/agent/cow/tmp/auto_daily_draft.html`
- 每条显示：赛道 + 地区 + 信息类型（官方/媒体/传闻），核心事实、产业影响、来源链接

## Step 5 — 部署与验证

```bash
python3 "<base_dir>/scripts/deploy_daily.py" auto /home/agent/cow/tmp/auto_daily_draft.html "YYYY年M月D日"
```

- 生成 `auto/index.html` + `archive/auto-YYYY-MM-DD.html`
- 部署后验证 https://taoleb.github.io/daily-news-pages/auto/ 可达；Pages 初次构建等待30—60秒后重试

## Step 6 — 汇报

汇报条目数、赛道覆盖、3—5条重点、采集/验证异常、版块页与归档链接。对传闻或未能一手确认的内容明确注明。

## 故障处理

| 症状 | 处置 |
|---|---|
| RSS 大面积失败 | 单源跳过；检查网络，Tavily八赛道补足 |
| 候选事件少于20 | 扩展八赛道 Tavily 查询，不降低事实验证标准 |
| Tavily 429/额度用尽 | 自动轮换 TAVILY_API_KEY_2~_5；耗尽则 RSS 出报并说明 |
| 一手来源不可访问 | 找第二可靠来源核对；仍不能确认则弱化/剔除 |
| 部署失败/线上404 | 检查 GITHUB_TOKEN Contents 写权限；等 Pages 构建后重试 |

## 关联资源

- 采集脚本：`/home/agent/cow/skills/auto-daily-report/scripts/collect_news.py`
- 模板：`/home/agent/cow/skills/auto-daily-report/assets/template.html`
- 部署脚本：`<base_dir>/scripts/deploy_daily.py`（随本技能打包；`base_dir` 是本 SKILL.md 所在目录。不要假设工作区根目录 `scripts/deploy_daily.py` 一定存在）
- 站点：https://taoleb.github.io/daily-news-pages/auto/
